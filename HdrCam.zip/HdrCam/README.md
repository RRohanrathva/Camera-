# HDR Cam – Redmi Note 14 5G (Dimensity 7025-Ultra, Samsung HM6 108MP)

ફક્ત ફોટોગ્રાફી માટે HDR કેમેરા એપ. 5 exposure (-3, -1.5, 0, +1.5, +3 EV) લઈને
OpenCV વડે align + Mertens exposure fusion કરે છે. પ્રોસેસિંગમાં વધારે સમય લાગે છે, પણ quality પહેલાં.

## APK કેવી રીતે બનાવવો
**રીત 1 – Android Studio (કમ્પ્યુટર):** `HdrCam` ફોલ્ડર ખોલો → Build > Build APK(s)
→ APK ફોનમાં નાખીને install કરો (Unknown sources allow કરવું).

**રીત 2 – ફોન/કમ્પ્યુટર વગર Studio:** ફોલ્ડરને GitHub repo માં upload કરો →
Actions > "Build APK" > Run workflow → Artifacts માંથી `HdrCam-apk` ડાઉનલોડ કરો.

## વાપરવાની રીત
ફોન સ્થિર પકડો (ટ્રાઇપોડ/ટેકો હોય તો શ્રેષ્ઠ) → "HDR ફોટો" દબાવો → લગભગ 5 સેકંડ ફોન હલાવશો નહીં →
merge પૂરો થાય એટલે ફોટો Pictures/HDRCam માં સેવ થશે.
