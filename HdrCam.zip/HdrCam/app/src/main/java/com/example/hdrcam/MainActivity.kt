package com.example.hdrcam

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.hardware.camera2.CaptureRequest
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.opencv.android.OpenCVLoader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var statusText: TextView
    private lateinit var shutter: Button

    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private val captureExecutor = Executors.newSingleThreadExecutor()
    private var busy = false

    // Exposure bracket in EV. 5 frames cover very high dynamic range scenes.
    private val bracketEv = floatArrayOf(-3f, -1.5f, 0f, 1.5f, 3f)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        check(OpenCVLoader.initLocal()) { "OpenCV load failed" }
        buildUi()

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera()
        else ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), 10)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code == 10 && res.firstOrNull() == PackageManager.PERMISSION_GRANTED) startCamera()
        else Toast.makeText(this, "કેમેરા પરવાનગી જરૂરી છે", Toast.LENGTH_LONG).show()
    }

    private fun buildUi() {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        previewView = PreviewView(this).apply {
            scaleType = PreviewView.ScaleType.FIT_CENTER
        }
        root.addView(previewView, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        statusText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 14f
            gravity = Gravity.CENTER
            setBackgroundColor(0x99000000.toInt())
            setPadding(24, 16, 24, 16)
            text = "HDR તૈયાર • ફોન સ્થિર પકડો"
        }
        root.addView(statusText, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP))

        shutter = Button(this).apply {
            text = "HDR ફોટો"
            setOnClickListener { captureHdr() }
        }
        root.addView(shutter, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = 96 })

        setContentView(root)
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()

            val resolution = ResolutionSelector.Builder()
                .setAspectRatioStrategy(AspectRatioStrategy(
                    AspectRatio.RATIO_4_3, AspectRatioStrategy.FALLBACK_RULE_AUTO))
                // Highest the main (Samsung HM6) camera exposes to 3rd-party apps
                .setResolutionStrategy(ResolutionStrategy.HIGHEST_AVAILABLE_STRATEGY)
                .build()

            val preview = Preview.Builder()
                .setResolutionSelector(ResolutionSelector.Builder()
                    .setAspectRatioStrategy(AspectRatioStrategy(
                        AspectRatio.RATIO_4_3, AspectRatioStrategy.FALLBACK_RULE_AUTO))
                    .build())
                .build().also { it.setSurfaceProvider(previewView.surfaceProvider) }

            val captureBuilder = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setResolutionSelector(resolution)
                .setJpegQuality(100)
            // Max quality noise reduction and sharpening from the ISP
            Camera2Interop.Extender(captureBuilder)
                .setCaptureRequestOption(CaptureRequest.NOISE_REDUCTION_MODE,
                    CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
                .setCaptureRequestOption(CaptureRequest.EDGE_MODE,
                    CaptureRequest.EDGE_MODE_HIGH_QUALITY)
            imageCapture = captureBuilder.build()

            provider.unbindAll()
            // Back main camera only (Samsung HM6 108MP, 9-in-1 binned)
            camera = provider.bindToLifecycle(
                this, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
        }, ContextCompat.getMainExecutor(this))
    }

    private fun captureHdr() {
        if (busy) return
        val cam = camera ?: return
        busy = true
        shutter.isEnabled = false

        lifecycleScope.launch {
            try {
                val range = cam.cameraInfo.exposureState.exposureCompensationRange
                val step = cam.cameraInfo.exposureState.exposureCompensationStep.toFloat()
                val frames = ArrayList<Bitmap>()

                for ((i, ev) in bracketEv.withIndex()) {
                    val idx = if (step > 0f) (ev / step).roundToInt()
                        .coerceIn(range.lower, range.upper) else 0
                    status("ફ્રેમ ${i + 1}/${bracketEv.size} લઈ રહ્યો છું… ફોન હલાવશો નહીં")
                    setEv(cam, idx)
                    delay(700) // let auto-exposure settle on the new EV
                    frames.add(grab())
                }
                setEv(cam, 0)

                val merged = withContext(Dispatchers.Default) {
                    HdrProcessor.merge(frames) { msg ->
                        runOnUiThread { statusText.text = msg }
                    }
                }
                frames.forEach { it.recycle() }

                status("સેવ કરી રહ્યો છું…")
                val ok = withContext(Dispatchers.IO) { save(merged) }
                merged.recycle()
                status(if (ok) "✔ HDR ફોટો ગેલેરીમાં સેવ થયો (Pictures/HDRCam)" else "સેવ નિષ્ફળ")
            } catch (e: Exception) {
                status("ભૂલ: ${e.message}")
            } finally {
                busy = false
                shutter.isEnabled = true
            }
        }
    }

    private fun status(msg: String) { statusText.text = msg }

    private suspend fun setEv(cam: Camera, index: Int) =
        suspendCancellableCoroutine<Unit> { c ->
            val f = cam.cameraControl.setExposureCompensationIndex(index)
            f.addListener({ if (c.isActive) c.resume(Unit) },
                ContextCompat.getMainExecutor(this))
        }

    private suspend fun grab(): Bitmap = suspendCancellableCoroutine { c ->
        imageCapture!!.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val raw = image.toBitmap()
                    val rot = image.imageInfo.rotationDegrees
                    val bmp = if (rot != 0) {
                        val m = Matrix().apply { postRotate(rot.toFloat()) }
                        Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                            .also { raw.recycle() }
                    } else raw
                    c.resume(bmp)
                } catch (e: Exception) {
                    c.resumeWithException(e)
                } finally {
                    image.close()
                }
            }

            override fun onError(exc: ImageCaptureException) {
                c.resumeWithException(exc)
            }
        })
    }

    private fun save(bmp: Bitmap): Boolean {
        val name = "HDR_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "$name.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/HDRCam")
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            ?: return false
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 98, it) }
            ?: return false
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        contentResolver.update(uri, values, null, null)
        return true
    }
}
