package com.example.hdrcam

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.CvType
import org.opencv.core.Mat
import org.opencv.imgproc.Imgproc
import org.opencv.photo.Photo

/**
 * Slow, high-quality HDR: align the bracketed frames (AlignMTB),
 * then Mertens exposure fusion (contrast + saturation + well-exposedness).
 * Processing time is deliberately not optimised - quality first.
 */
object HdrProcessor {

    fun merge(frames: List<Bitmap>, onProgress: (String) -> Unit): Bitmap {
        require(frames.size >= 2) { "Need at least 2 frames" }

        onProgress("ફ્રેમ તૈયાર કરી રહ્યો છું…")
        val mats = ArrayList<Mat>()
        for (bmp in frames) {
            val rgba = Mat()
            Utils.bitmapToMat(bmp, rgba)
            val rgb = Mat()
            Imgproc.cvtColor(rgba, rgb, Imgproc.COLOR_RGBA2RGB)
            rgba.release()
            mats.add(rgb)
        }

        onProgress("ફ્રેમ align કરી રહ્યો છું (હાથ હલવાથી થયેલો ફરક સુધારવા)…")
        Photo.createAlignMTB(6, 4, true).process(mats, mats)

        onProgress("HDR merge (Mertens fusion) ચાલુ છે…")
        val fusion = Mat()
        val merge = Photo.createMergeMertens(1.0f, 1.0f, 1.0f)
        merge.process(mats, fusion)
        mats.forEach { it.release() }

        onProgress("અંતિમ ફોટો બનાવી રહ્યો છું…")
        val out8 = Mat()
        fusion.convertTo(out8, CvType.CV_8UC3, 255.0)
        fusion.release()
        // Mertens can slightly overshoot the 0..1 range
        Core.min(out8, org.opencv.core.Scalar(255.0, 255.0, 255.0), out8)

        val rgbaOut = Mat()
        Imgproc.cvtColor(out8, rgbaOut, Imgproc.COLOR_RGB2RGBA)
        out8.release()

        val result = Bitmap.createBitmap(rgbaOut.cols(), rgbaOut.rows(), Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(rgbaOut, result)
        rgbaOut.release()
        return result
    }
}
