# HDR Cam v2 – Redmi Note 14 5G (Dimensity 7025-Ultra, Samsung HM6 108MP)

સ્ટોક કેમેરા જેવું UI: ટોપ બાર (ફ્લેશ, ગ્રિડ, HDR, 3:4/9:16), ઝૂમ 0.6 / 1× / 2, Video / Photo ટેબ,
શટર, ગેલેરી થંબનેલ, ફ્રન્ટ/બેક સ્વિચ, ટેપ-ટુ-ફોકસ, પિંચ-ઝૂમ.

- **HDR ON**: 5 exposure (-3, -1.5, 0, +1.5, +3 EV) → align + Mertens fusion + હળવું શાર્પનિંગ
- **HDR A (Auto)**: સીન માં બહુ તેજસ્વી/અંધારા ભાગ હોય તો જ HDR
- **HDR OFF**: સામાન્ય એક ફોટો
- 5 ફ્રેમ પછી ફોન હલાવી શકો છો – merge બેકગ્રાઉન્ડમાં થાય છે (એપ ખુલ્લી રાખો, "✔ સેવ થયો" આવે ત્યાં સુધી)
- ફોટો/વિડિયો DCIM/Camera માં સેવ થાય છે (ગેલેરીના Camera આલ્બમમાં દેખાશે)

## APK
Android Studio: ફોલ્ડર ખોલો → Build > Build APK(s).
અથવા GitHub પર અપલોડ કરી Actions > "Build APK" ચલાવો.
જૂની એપ પહેલાં uninstall કરો (signature અલગ હોય તો update નહીં થાય).
