package com.example.hdrcam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View
import kotlin.math.min

/** Round shutter button: white (photo), red (video), red square while recording. */
class ShutterView(ctx: Context) : View(ctx) {

    var isVideo = false
        set(v) { field = v; invalidate() }
    var recording = false
        set(v) { field = v; invalidate() }
    var busy = false
        set(v) { field = v; invalidate() }

    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = Color.WHITE
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val cx = width / 2f
        val cy = height / 2f
        val outer = min(width, height) / 2f - 3f * d
        ring.strokeWidth = 4f * d
        c.drawCircle(cx, cy, outer, ring)

        fill.color = when {
            busy -> 0xFF9E9E9E.toInt()
            isVideo -> 0xFFE53935.toInt()
            else -> Color.WHITE
        }
        if (recording) {
            val half = outer * 0.38f
            c.drawRoundRect(cx - half, cy - half, cx + half, cy + half, 8f * d, 8f * d, fill)
        } else {
            c.drawCircle(cx, cy, outer - 8f * d, fill)
        }
    }
}
