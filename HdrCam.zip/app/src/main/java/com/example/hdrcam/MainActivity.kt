package com.example.hdrcam

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Outline
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.CaptureRequest
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.SpannableString
import android.text.style.RelativeSizeSpan
import android.text.style.SubscriptSpan
import android.util.Log
import android.util.Size
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.camera2.interop.Camera2Interop
import androidx.camera.core.AspectRatio
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.opencv.android.OpenCVLoader
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : AppCompatActivity() {

    private enum class Mode { PHOTO, VIDEO }
    private enum class HdrMode(val suffix: String) { ON(" ON"), AUTO(" A"), OFF(" OFF") }

    private companion object {
        const val TAG = "HdrCam"
        const val BLUE = 0xFF1E90FF.toInt()
        const val AE_SETTLE_MS = 450L
    }

    // ---- views ----
    private lateinit var root: FrameLayout
    private lateinit var previewBox: FrameLayout
    private lateinit var previewView: PreviewView
    private lateinit var gridView: GridView
    private lateinit var focusRing: View
    private lateinit var statusText: TextView
    private lateinit var timerText: TextView
    private lateinit var zoomRow: LinearLayout
    private val zoomPills = LinkedHashMap<Float, TextView>()
    private lateinit var flashBtn: IconView
    private lateinit var gridBtn: IconView
    private lateinit var hdrBtn: TextView
    private lateinit var ratioBtn: TextView
    private lateinit var bottomPanel: LinearLayout
    private lateinit var tabVideo: TextView
    private lateinit var tabPhoto: TextView
    private lateinit var thumb: ImageView
    private lateinit var shutter: ShutterView
    private lateinit var switchBtn: IconView

    // ---- state ----
    private var mode = Mode.PHOTO
    private var hdrMode = HdrMode.ON
    private var useFront = false
    private var ratio43 = true
    private var flashOn = false
    private var screenW = 0
    private var screenH = 0

    private var provider: ProcessCameraProvider? = null
    private var camera: Camera? = null
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var recording: Recording? = null
    private var capturing = false
    private var pendingJobs = 0
    private var lastUri: Uri? = null
    private var timerJob: Job? = null

    private val zoomRatios = floatArrayOf(0.6f, 1f, 2f)
    private val handler = Handler(Looper.getMainLooper())
    private val hideStatus = Runnable { statusText.visibility = View.GONE }
    private val captureExecutor = Executors.newSingleThreadExecutor()
    // HDR merging runs in the background, so you may move the phone right after capture
    private val processScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val mergeMutex = Mutex()

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun roundBg(color: Int, radiusDp: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp).toFloat()
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.BLACK
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        check(OpenCVLoader.initLocal()) { "OpenCV load failed" }

        buildUi()

        val needed = arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            .filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (needed.isEmpty()) startCamera()
        else ActivityCompat.requestPermissions(this, needed.toTypedArray(), 10)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (code != 10) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) startCamera()
        else Toast.makeText(this, "કેમેરા પરવાનગી જરૂરી છે", Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        recording?.stop()
        captureExecutor.shutdown()
    }

    // ------------------------------------------------------------------ UI

    private fun buildUi() {
        val dm = resources.displayMetrics
        screenW = dm.widthPixels
        screenH = dm.heightPixels

        root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }

        // ----- preview area (grid, zoom pills, focus ring, status live inside it)
        previewBox = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        previewView = PreviewView(this).apply { scaleType = PreviewView.ScaleType.FILL_CENTER }
        previewBox.addView(previewView, match())

        gridView = GridView(this).apply { visibility = View.GONE }
        previewBox.addView(gridView, match())

        focusRing = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setStroke(dp(2), Color.WHITE)
                setColor(Color.TRANSPARENT)
            }
            visibility = View.GONE
        }
        previewBox.addView(focusRing, FrameLayout.LayoutParams(dp(64), dp(64)))

        timerText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 16f
            setPadding(dp(12), dp(4), dp(12), dp(4))
            background = roundBg(0xAAE53935.toInt(), 14)
            visibility = View.GONE
        }
        previewBox.addView(timerText, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply { topMargin = dp(72) })

        statusText = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(8), dp(14), dp(8))
            background = roundBg(0xAA000000.toInt(), 16)
            visibility = View.GONE
            setOnClickListener { visibility = View.GONE }
        }
        previewBox.addView(statusText, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(76); marginStart = dp(16); marginEnd = dp(16)
        })

        zoomRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = roundBg(0x66000000, 20)
            setPadding(dp(6), dp(4), dp(6), dp(4))
        }
        val labels = mapOf(0.6f to "0.6", 1f to "1×", 2f to "2")
        for (r in zoomRatios) {
            val pill = TextView(this).apply {
                text = labels[r]
                textSize = 14f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setPadding(dp(14), dp(7), dp(14), dp(7))
                setOnClickListener { setZoom(r) }
            }
            zoomPills[r] = pill
            zoomRow.addView(pill)
        }
        previewBox.addView(zoomRow, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(14) })

        root.addView(previewBox, FrameLayout.LayoutParams(screenW, screenW * 4 / 3, Gravity.TOP))

        // pinch to zoom + tap to focus
        val scaleDetector = ScaleGestureDetector(this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScale(d: ScaleGestureDetector): Boolean {
                    val cam = camera ?: return true
                    val z = cam.cameraInfo.zoomState.value ?: return true
                    val r = (z.zoomRatio * d.scaleFactor).coerceIn(z.minZoomRatio, z.maxZoomRatio)
                    cam.cameraControl.setZoomRatio(r)
                    return true
                }
            })
        val tapDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onSingleTapUp(e: MotionEvent): Boolean {
                focusAt(e.x, e.y)
                return true
            }
        })
        previewView.setOnTouchListener { _, ev ->
            scaleDetector.onTouchEvent(ev)
            tapDetector.onTouchEvent(ev)
            true
        }

        // ----- top bar: flash | grid | HDR | ratio
        flashBtn = IconView(this, IconView.Type.FLASH).apply { setOnClickListener { toggleFlash() } }
        gridBtn = IconView(this, IconView.Type.GRID).apply {
            setOnClickListener {
                active = !active
                gridView.visibility = if (active) View.VISIBLE else View.GONE
            }
        }
        hdrBtn = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            setOnClickListener { cycleHdr() }
        }
        ratioBtn = TextView(this).apply {
            gravity = Gravity.CENTER
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(Color.WHITE)
            text = "3:4"
            setOnClickListener { toggleRatio() }
        }
        val topBar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (v in listOf<View>(flashBtn, gridBtn, hdrBtn, ratioBtn)) {
            topBar.addView(v, LinearLayout.LayoutParams(0, dp(48), 1f))
        }
        root.addView(topBar, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, dp(56), Gravity.TOP).apply { topMargin = dp(8) })

        // ----- bottom panel: mode tabs + (thumbnail | shutter | switch camera)
        tabVideo = tab("Video") { setMode(Mode.VIDEO) }
        tabPhoto = tab("Photo") { setMode(Mode.PHOTO) }
        val tabs = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(tabVideo)
            addView(tabPhoto)
        }

        thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = roundBg(0xFF333333.toInt(), 10)
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(view: View, outline: Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, dp(10).toFloat())
                }
            }
            clipToOutline = true
            setOnClickListener { openGallery() }
        }
        shutter = ShutterView(this).apply { setOnClickListener { onShutter() } }
        switchBtn = IconView(this, IconView.Type.SWITCH).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0x33FFFFFF)
            }
            setOnClickListener { switchCamera() }
        }
        val shutterRow = FrameLayout(this)
        shutterRow.addView(thumb, FrameLayout.LayoutParams(dp(52), dp(52),
            Gravity.START or Gravity.CENTER_VERTICAL).apply { marginStart = dp(36) })
        shutterRow.addView(shutter, FrameLayout.LayoutParams(dp(84), dp(84), Gravity.CENTER))
        shutterRow.addView(switchBtn, FrameLayout.LayoutParams(dp(52), dp(52),
            Gravity.END or Gravity.CENTER_VERTICAL).apply { marginEnd = dp(36) })

        bottomPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(0, 0, 0, dp(16))
            addView(tabs, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48)))
            addView(shutterRow, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(104)))
        }
        root.addView(bottomPanel, FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM))

        setContentView(root)
        applyPreviewLayout()
        updateModeUi()
        updateHdrLabel()
    }

    private fun match() = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

    private fun tab(label: String, onClick: () -> Unit) = TextView(this).apply {
        text = label
        textSize = 16f
        setTypeface(typeface, android.graphics.Typeface.BOLD)
        gravity = Gravity.CENTER
        setPadding(dp(20), dp(10), dp(20), dp(10))
        setOnClickListener { onClick() }
    }

    /** 3:4 photo preview sits below the top bar like the stock camera; 16:9 goes full height. */
    private fun applyPreviewLayout() {
        val is43 = mode == Mode.PHOTO && ratio43
        val h = if (is43) screenW * 4 / 3 else screenW * 16 / 9
        val free = screenH - h - dp(168)
        val top = if (is43) maxOf(dp(72), (free * 0.4f).toInt()) else maxOf(0, (free * 0.4f).toInt())
        previewBox.layoutParams = FrameLayout.LayoutParams(screenW, h, Gravity.TOP).apply { topMargin = top }
        bottomPanel.setBackgroundColor(if (is43) Color.BLACK else 0x66000000)
        previewBox.requestLayout()
    }

    private fun updateModeUi() {
        tabPhoto.setTextColor(if (mode == Mode.PHOTO) BLUE else Color.WHITE)
        tabVideo.setTextColor(if (mode == Mode.VIDEO) BLUE else Color.WHITE)
        val photo = mode == Mode.PHOTO
        hdrBtn.visibility = if (photo) View.VISIBLE else View.INVISIBLE
        ratioBtn.visibility = if (photo) View.VISIBLE else View.INVISIBLE
        shutter.isVideo = !photo
    }

    private fun updateHdrLabel() {
        val s = SpannableString("HDR" + hdrMode.suffix)
        s.setSpan(RelativeSizeSpan(0.6f), 3, s.length, 0)
        s.setSpan(SubscriptSpan(), 3, s.length, 0)
        hdrBtn.text = s
        hdrBtn.alpha = if (hdrMode == HdrMode.OFF) 0.55f else 1f
    }

    private fun setStatus(msg: String?, autoHide: Boolean = true) {
        runOnUiThread {
            handler.removeCallbacks(hideStatus)
            if (msg == null) {
                statusText.visibility = View.GONE
                return@runOnUiThread
            }
            statusText.text = msg
            statusText.visibility = View.VISIBLE
            if (autoHide) handler.postDelayed(hideStatus, 3500)
        }
    }

    // ------------------------------------------------------------------ controls

    private fun cycleHdr() {
        hdrMode = HdrMode.values()[(hdrMode.ordinal + 1) % HdrMode.values().size]
        updateHdrLabel()
        setStatus(when (hdrMode) {
            HdrMode.ON -> "HDR ચાલુ: દરેક ફોટામાં 5-ફ્રેમ HDR"
            HdrMode.AUTO -> "HDR ઓટો: જરૂર હોય ત્યારે જ HDR"
            HdrMode.OFF -> "HDR બંધ: સામાન્ય ફોટો"
        })
    }

    private fun toggleRatio() {
        if (recording != null || capturing) return
        ratio43 = !ratio43
        ratioBtn.text = if (ratio43) "3:4" else "9:16"
        applyPreviewLayout()
        bindUseCases()
    }

    private fun toggleFlash() {
        flashOn = !flashOn
        flashBtn.active = flashOn
        applyFlash()
        if (flashOn && mode == Mode.PHOTO) setStatus("ફ્લેશ ચાલુ: ફ્લેશ સાથે સામાન્ય ફોટો (HDR નહીં)")
    }

    private fun applyFlash() {
        imageCapture?.flashMode =
            if (flashOn && mode == Mode.PHOTO) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
        camera?.cameraControl?.enableTorch(flashOn && mode == Mode.VIDEO)
    }

    private fun setMode(m: Mode) {
        if (recording != null || capturing || m == mode) return
        mode = m
        updateModeUi()
        applyPreviewLayout()
        bindUseCases()
    }

    private fun switchCamera() {
        if (recording != null || capturing) return
        useFront = !useFront
        if (useFront) { flashOn = false; flashBtn.active = false }
        bindUseCases()
    }

    private fun setZoom(r: Float) {
        val cam = camera ?: return
        val z = cam.cameraInfo.zoomState.value ?: return
        cam.cameraControl.setZoomRatio(r.coerceIn(z.minZoomRatio, z.maxZoomRatio))
    }

    private fun updateZoomPills(ratio: Float) {
        for ((r, tv) in zoomPills) {
            tv.setTextColor(if (abs(r - ratio) < 0.12f) BLUE else Color.WHITE)
        }
    }

    private fun focusAt(x: Float, y: Float) {
        val cam = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(x, y)
        cam.cameraControl.startFocusAndMetering(FocusMeteringAction.Builder(point).build())
        focusRing.x = x - focusRing.layoutParams.width / 2f
        focusRing.y = y - focusRing.layoutParams.height / 2f
        focusRing.animate().cancel()
        focusRing.alpha = 1f
        focusRing.visibility = View.VISIBLE
        focusRing.animate().alpha(0f).setStartDelay(700).setDuration(300)
            .withEndAction { focusRing.visibility = View.GONE }.start()
    }

    private fun onShutter() {
        when (mode) {
            Mode.PHOTO -> takePhoto()
            Mode.VIDEO -> toggleRecording()
        }
    }

    // ------------------------------------------------------------------ camera binding

    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            provider = f.get()
            bindUseCases()
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindUseCases() {
        val p = provider ?: return
        if (recording != null) return

        val is43 = mode == Mode.PHOTO && ratio43
        val aspect = AspectRatioStrategy(
            if (is43) AspectRatio.RATIO_4_3 else AspectRatio.RATIO_16_9,
            AspectRatioStrategy.FALLBACK_RULE_AUTO)
        val selector = if (useFront) CameraSelector.DEFAULT_FRONT_CAMERA
        else CameraSelector.DEFAULT_BACK_CAMERA

        val preview = Preview.Builder()
            .setResolutionSelector(ResolutionSelector.Builder().setAspectRatioStrategy(aspect).build())
            .build()
        preview.setSurfaceProvider(previewView.surfaceProvider)

        p.unbindAll()
        try {
            if (mode == Mode.PHOTO) {
                // Cap at 12MP (the 9-in-1 binned HM6 output). Full 108MP frames x5 would run out of memory.
                val resolution = ResolutionSelector.Builder()
                    .setAspectRatioStrategy(aspect)
                    .setResolutionStrategy(ResolutionStrategy(
                        Size(4000, 3000), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER))
                    .build()
                val b = ImageCapture.Builder()
                    .setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                    .setResolutionSelector(resolution)
                    .setJpegQuality(100)
                Camera2Interop.Extender(b)
                    .setCaptureRequestOption(CaptureRequest.NOISE_REDUCTION_MODE,
                        CaptureRequest.NOISE_REDUCTION_MODE_HIGH_QUALITY)
                    .setCaptureRequestOption(CaptureRequest.EDGE_MODE,
                        CaptureRequest.EDGE_MODE_HIGH_QUALITY)
                val ic = b.build()
                imageCapture = ic
                videoCapture = null
                camera = p.bindToLifecycle(this, selector, preview, ic)
            } else {
                val recorder = Recorder.Builder()
                    .setQualitySelector(QualitySelector.from(
                        Quality.FHD, FallbackStrategy.lowerQualityOrHigherThan(Quality.FHD)))
                    .build()
                val vcap = VideoCapture.withOutput(recorder)
                videoCapture = vcap
                imageCapture = null
                camera = p.bindToLifecycle(this, selector, preview, vcap)
            }
        } catch (t: Throwable) {
            Log.e(TAG, "bind failed", t)
            setStatus("કેમેરા ચાલુ ન થયો: ${t.javaClass.simpleName}: ${t.message}", false)
            return
        }

        val cam = camera ?: return
        flashBtn.visibility = if (useFront) View.INVISIBLE else View.VISIBLE
        applyFlash()

        // zoom pills: show 0.6 only if the ultra-wide is exposed to apps
        val zs = cam.cameraInfo.zoomState.value
        zoomRow.visibility = if (useFront) View.GONE else View.VISIBLE
        zoomPills[0.6f]?.visibility = if ((zs?.minZoomRatio ?: 1f) <= 0.65f) View.VISIBLE else View.GONE
        zoomPills[2f]?.visibility = if ((zs?.maxZoomRatio ?: 1f) >= 2f) View.VISIBLE else View.GONE
        cam.cameraInfo.zoomState.observe(this) { z -> updateZoomPills(z.zoomRatio) }
        cam.cameraControl.setZoomRatio(1f)
    }

    // ------------------------------------------------------------------ photo

    private fun takePhoto() {
        val cam = camera ?: return
        if (capturing) return
        if (pendingJobs >= 2) {
            setStatus("પાછલા ફોટા હજી પ્રોસેસ થઈ રહ્યા છે… થોડી રાહ જુઓ")
            return
        }
        capturing = true
        shutter.busy = true

        lifecycleScope.launch {
            var frames: List<Bitmap>? = null
            var hdr = false
            try {
                val st = cam.cameraInfo.exposureState
                val wantHdr = hdrMode != HdrMode.OFF && !flashOn && st.isExposureCompensationSupported
                if (!wantHdr) {
                    frames = listOf(grab())
                } else {
                    val range = st.exposureCompensationRange
                    val step = st.exposureCompensationStep.toFloat()
                    val idx = { ev: Float ->
                        if (step > 0f) (ev / step).roundToInt().coerceIn(range.lower, range.upper) else 0
                    }
                    setStatus("ફ્રેમ 1/5… ફોન થોડી વાર સ્થિર પકડો", false)
                    setEv(cam, 0)
                    delay(150)
                    val base = grab()
                    if (hdrMode == HdrMode.AUTO && !isHighContrast(base)) {
                        frames = listOf(base)
                    } else {
                        val neg = ArrayList<Bitmap>()
                        val pos = ArrayList<Bitmap>()
                        var n = 1
                        for (ev in floatArrayOf(-3f, -1.5f)) {
                            n++
                            setStatus("ફ્રેમ $n/5…", false)
                            setEv(cam, idx(ev)); delay(AE_SETTLE_MS)
                            neg.add(grab())
                        }
                        for (ev in floatArrayOf(1.5f, 3f)) {
                            n++
                            setStatus("ફ્રેમ $n/5…", false)
                            setEv(cam, idx(ev)); delay(AE_SETTLE_MS)
                            pos.add(grab())
                        }
                        frames = neg + base + pos   // dark -> bright, EV0 in the middle
                        hdr = true
                    }
                }
            } catch (t: Throwable) {
                Log.e(TAG, "capture failed", t)
                setStatus("કેપ્ચર ભૂલ: ${t.javaClass.simpleName}: ${t.message}", false)
            } finally {
                cam.cameraControl.setExposureCompensationIndex(0)
                capturing = false
                shutter.busy = false
            }
            frames?.let {
                setStatus(if (hdr) "✔ કેપ્ચર પૂરું — હવે ફોન હલાવી શકો છો. HDR પ્રોસેસ ચાલુ…"
                          else "✔ કેપ્ચર પૂરું — સેવ કરી રહ્યો છું…", false)
                queueSave(it, hdr)
            }
        }
    }

    /** Dark-and-bright-heavy scenes (window + dark room) need HDR; flat scenes don't. */
    private fun isHighContrast(bmp: Bitmap): Boolean {
        val w = 96
        val h = 72
        val s = Bitmap.createScaledBitmap(bmp, w, h, true)
        val px = IntArray(w * h)
        s.getPixels(px, 0, w, 0, 0, w, h)
        if (s !== bmp) s.recycle()
        var clipped = 0
        for (c in px) {
            val l = (Color.red(c) * 299 + Color.green(c) * 587 + Color.blue(c) * 114) / 1000
            if (l < 10 || l > 245) clipped++
        }
        return clipped.toFloat() / px.size > 0.05f
    }

    private suspend fun setEv(cam: Camera, index: Int) = suspendCancellableCoroutine<Unit> { c ->
        val f = cam.cameraControl.setExposureCompensationIndex(index)
        f.addListener({ if (c.isActive) c.resume(Unit) }, ContextCompat.getMainExecutor(this))
    }

    private suspend fun grab(): Bitmap = suspendCancellableCoroutine { c ->
        imageCapture!!.takePicture(captureExecutor, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val raw = image.toBitmap()
                    val rot = image.imageInfo.rotationDegrees
                    val bmp = if (rot != 0) {
                        val m = Matrix().apply { postRotate(rot.toFloat()) }
                        Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, m, true)
                            .also { raw.recycle() }
                    } else raw
                    c.resume(bmp)
                } catch (e: Exception) {
                    c.resumeWithException(e)
                } finally {
                    image.close()
                }
            }

            override fun onError(exc: ImageCaptureException) {
                c.resumeWithException(exc)
            }
        })
    }

    /** Merge + save in the background; the shutter is already free again. */
    private fun queueSave(frames: List<Bitmap>, hdr: Boolean) {
        pendingJobs++
        val appCtx = applicationContext
        processScope.launch {
            mergeMutex.withLock {
                try {
                    val mid = frames[frames.size / 2]
                    var result: Bitmap = mid
                    var merged = false
                    if (hdr && frames.size > 1) {
                        try {
                            result = HdrProcessor.merge(frames) { msg -> setStatus("HDR: $msg", false) }
                            merged = true
                        } catch (t: Throwable) {
                            // never lose the photo: save the normal exposure instead
                            Log.e(TAG, "merge failed", t)
                            setStatus("HDR merge ફેલ (${t.javaClass.simpleName}) — સામાન્ય ફોટો સેવ કરું છું", false)
                            result = mid
                        }
                    }
                    val uri = savePhoto(appCtx, result, merged)
                    if (result !== mid && !result.isRecycled) result.recycle()
                    frames.forEach { if (!it.isRecycled) it.recycle() }
                    if (uri != null) {
                        runOnUiThread { lastUri = uri; showThumb(uri) }
                        setStatus(if (merged) "✔ HDR ફોટો ગેલેરીમાં સેવ થયો" else "✔ ફોટો ગેલેરીમાં સેવ થયો")
                    } else {
                        setStatus("સેવ નિષ્ફળ (MediaStore)", false)
                    }
                } catch (t: Throwable) {
                    Log.e(TAG, "save failed", t)
                    setStatus("ભૂલ: ${t.javaClass.simpleName}: ${t.message}", false)
                } finally {
                    pendingJobs--
                }
            }
        }
    }

    private fun savePhoto(ctx: Context, bmp: Bitmap, hdr: Boolean): Uri? {
        val name = "IMG_" + stamp() + if (hdr) "_HDR" else ""
        val values = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "$name.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "DCIM/Camera")
            put(MediaStore.Images.Media.DATE_TAKEN, System.currentTimeMillis())
            put(MediaStore.Images.Media.IS_PENDING, 1)
        }
        val resolver = ctx.contentResolver
        val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: return null
        val ok = resolver.openOutputStream(uri)?.use {
            bmp.compress(Bitmap.CompressFormat.JPEG, 98, it)
        } ?: false
        if (!ok) {
            resolver.delete(uri, null, null)
            return null
        }
        values.clear()
        values.put(MediaStore.Images.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        return uri
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    // ------------------------------------------------------------------ video

    private fun toggleRecording() {
        val vc = videoCapture ?: return
        val active = recording
        if (active != null) {
            active.stop()
            return
        }

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "VID_" + stamp())
            put(MediaStore.Video.Media.RELATIVE_PATH, "DCIM/Camera")
        }
        val opts = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
            .setContentValues(values)
            .build()
        var pending = vc.output.prepareRecording(this, opts)
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            == PackageManager.PERMISSION_GRANTED
        ) pending = pending.withAudioEnabled()

        recording = pending.start(ContextCompat.getMainExecutor(this)) { ev ->
            when (ev) {
                is VideoRecordEvent.Start -> {
                    shutter.recording = true
                    startTimer()
                }
                is VideoRecordEvent.Finalize -> {
                    recording = null
                    shutter.recording = false
                    stopTimer()
                    if (!ev.hasError()) {
                        val uri = ev.outputResults.outputUri
                        lastUri = uri
                        showThumb(uri)
                        setStatus("✔ વિડિયો ગેલેરીમાં સેવ થયો")
                    } else {
                        setStatus("વિડિયો ભૂલ (કોડ ${ev.error})", false)
                    }
                }
                else -> {}
            }
        }
    }

    private fun startTimer() {
        timerText.visibility = View.VISIBLE
        timerJob?.cancel()
        timerJob = lifecycleScope.launch {
            var s = 0
            while (isActive) {
                timerText.text = String.format(Locale.US, "● %02d:%02d", s / 60, s % 60)
                delay(1000)
                s++
            }
        }
    }

    private fun stopTimer() {
        timerJob?.cancel()
        timerText.visibility = View.GONE
    }

    // ------------------------------------------------------------------ gallery

    private fun showThumb(uri: Uri) {
        lifecycleScope.launch {
            val bmp = withContext(Dispatchers.IO) {
                try { contentResolver.loadThumbnail(uri, Size(256, 256), null) } catch (e: Exception) { null }
            }
            if (bmp != null) thumb.setImageBitmap(bmp)
        }
    }

    private fun openGallery() {
        try {
            val u = lastUri
            if (u != null) {
                val type = contentResolver.getType(u) ?: "image/*"
                startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, type)
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            } else {
                startActivity(Intent.makeMainSelectorActivity(
                    Intent.ACTION_MAIN, Intent.CATEGORY_APP_GALLERY))
            }
        } catch (e: Exception) {
            Toast.makeText(this, "ગેલેરી ખોલી શકાઈ નહીં", Toast.LENGTH_SHORT).show()
        }
    }
}
