package com.example.hdrcam

import android.graphics.Bitmap
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc

enum class BokehStyle {
    NATURAL,
    CINEMATIC,
    STUDIO
}

object PortraitProcessor {

    /**
     * OpenCV based Depth-of-Field & Bokeh effect with edge preservation
     */
    fun processPortrait(src: Bitmap, blurRadius: Int = 31, style: BokehStyle = BokehStyle.NATURAL): Bitmap {
        val srcMat = Mat()
        Utils.bitmapToMat(src, srcMat)

        // Convert to RGB
        val rgbMat = Mat()
        Imgproc.cvtColor(srcMat, rgbMat, Imgproc.COLOR_RGBA2RGB)

        // Edge preserving filter
        val blurredMat = Mat()
        Imgproc.GaussianBlur(rgbMat, blurredMat, Size(blurRadius.toDouble(), blurRadius.toDouble()), 0.0)

        // Center-weighted portrait radial mask (keeps center subject sharp, blurs background)
        val mask = Mat(rgbMat.rows(), rgbMat.cols(), CvType.CV_32F)
        val cx = rgbMat.cols() / 2.0
        val cy = rgbMat.rows() / 2.0
        val maxR = Math.hypot(cx, cy) * 0.75

        // Create smooth depth transition
        for (r in 0 until rgbMat.rows()) {
            for (c in 0 until rgbMat.cols()) {
                val dist = Math.hypot(c - cx, r - cy)
                val factor = ((dist - maxR * 0.35) / (maxR * 0.65)).coerceIn(0.0, 1.0)
                mask.put(r, c, factor)
            }
        }

        // Blend sharp foreground and blurred background
        val rgbFloat = Mat()
        val blurFloat = Mat()
        rgbMat.convertTo(rgbFloat, CvType.CV_32FC3)
        blurredMat.convertTo(blurFloat, CvType.CV_32FC3)

        val chSrc = ArrayList<Mat>()
        val chBlur = ArrayList<Mat>()
        Core.split(rgbFloat, chSrc)
        Core.split(blurFloat, chBlur)

        val invMask = Mat()
        Core.subtract(Scalar(1.0), mask, invMask)

        val outCh = ArrayList<Mat>()
        for (i in 0 until 3) {
            val fg = Mat()
            val bg = Mat()
            val res = Mat()
            Core.multiply(chSrc[i], invMask, fg)
            Core.multiply(chBlur[i], mask, bg)
            Core.add(fg, bg, res)
            outCh.add(res)
            fg.release()
            bg.release()
        }

        val blended = Mat()
        Core.merge(outCh, blended)

        // Apply style grading
        if (style == BokehStyle.CINEMATIC) {
            Core.multiply(blended, Scalar(0.95, 0.98, 1.05), blended)
        }

        blended.convertTo(rgbMat, CvType.CV_8UC3)
        Imgproc.cvtColor(rgbMat, srcMat, Imgproc.COLOR_RGB2RGBA)

        val outBmp = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        Utils.matToBitmap(srcMat, outBmp)

        srcMat.release()
        rgbMat.release()
        blurredMat.release()
        mask.release()
        invMask.release()
        rgbFloat.release()
        blurFloat.release()
        blended.release()

        return outBmp
    }
}
