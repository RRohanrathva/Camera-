package com.example.hdrcam

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class HdrProcessingService : Service() {

    companion object {
        const val CHANNEL_ID = "hdr_processing_channel"
        const val NOTIF_ID = 1001
        const val EXTRA_PROGRESS = "progress"
        const val EXTRA_STATUS = "status"

        fun updateProgress(ctx: Context, progress: Int, statusText: String) {
            val intent = Intent(ctx, HdrProcessingService::class.java).apply {
                putExtra(EXTRA_PROGRESS, progress)
                putExtra(EXTRA_STATUS, statusText)
            }
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    ctx.startForegroundService(intent)
                } else {
                    ctx.startService(intent)
                }
            } catch (e: Exception) {
                // Ignore if service cannot be started in background
            }
        }

        fun stop(ctx: Context) {
            try {
                ctx.stopService(Intent(ctx, HdrProcessingService::class.java))
            } catch (e: Exception) {}
        }
    }

    private var manager: NotificationManager? = null
    private var builder: NotificationCompat.Builder? = null

    override fun onCreate() {
        super.onCreate()
        manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createChannel()
        builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.stat_sys_upload)
            .setContentTitle("HDR / Portrait પ્રોસેસિંગ...")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setProgress(100, 0, false)
        startForeground(NOTIF_ID, builder!!.build())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val progress = intent?.getIntExtra(EXTRA_PROGRESS, -1) ?: -1
        val status = intent?.getStringExtra(EXTRA_STATUS) ?: "પ્રોસેસિંગ..."

        if (progress in 0..100) {
            builder?.setContentText("$status ($progress%)")
                ?.setProgress(100, progress, false)
            manager?.notify(NOTIF_ID, builder!!.build())
        }
        return START_NOT_STICKY
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "HDR Processing Channel",
                NotificationManager.IMPORTANCE_LOW
            )
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
