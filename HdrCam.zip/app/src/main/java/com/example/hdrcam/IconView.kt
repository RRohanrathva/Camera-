package com.example.hdrcam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Small vector-style icons drawn with Canvas (no font / drawable dependency). */
class IconView(ctx: Context, private val type: Type) : View(ctx) {

    enum class Type { FLASH, GRID, SWITCH }

    var active = false
        set(v) { field = v; invalidate() }

    private val density = resources.displayMetrics.density
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.4f * density
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.WHITE
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = Color.WHITE
    }

    override fun onDraw(c: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val u = min(width, height) * 0.30f
        when (type) {
            Type.FLASH -> {
                val p = Path().apply {
                    moveTo(cx + 0.25f * u, cy - u)
                    lineTo(cx - 0.55f * u, cy + 0.15f * u)
                    lineTo(cx - 0.05f * u, cy + 0.15f * u)
                    lineTo(cx - 0.25f * u, cy + u)
                    lineTo(cx + 0.55f * u, cy - 0.15f * u)
                    lineTo(cx + 0.05f * u, cy - 0.15f * u)
                    close()
                }
                if (active) c.drawPath(p, fill) else {
                    c.drawPath(p, stroke)
                    c.drawLine(cx - u, cy - u, cx + u, cy + u, stroke) // "off" slash
                }
            }
            Type.GRID -> {
                stroke.color = if (active) 0xFF1E90FF.toInt() else Color.WHITE
                val r = RectF(cx - u, cy - u, cx + u, cy + u)
                c.drawRoundRect(r, u * 0.2f, u * 0.2f, stroke)
                for (i in 1..2) {
                    val t = -u + 2f * u * i / 3f
                    c.drawLine(cx + t, cy - u, cx + t, cy + u, stroke)
                    c.drawLine(cx - u, cy + t, cx + u, cy + t, stroke)
                }
                stroke.color = Color.WHITE
            }
            Type.SWITCH -> {
                val r = u * 0.85f
                val box = RectF(cx - r, cy - r, cx + r, cy + r)
                c.drawArc(box, 200f, 130f, false, stroke)
                c.drawArc(box, 20f, 130f, false, stroke)
                arrow(c, cx, cy, r, 330f, u)
                arrow(c, cx, cy, r, 150f, u)
            }
        }
    }

    /** Filled arrow head at the end of a clockwise arc, at angle [deg]. */
    private fun arrow(c: Canvas, cx: Float, cy: Float, r: Float, deg: Float, u: Float) {
        val th = Math.toRadians(deg.toDouble())
        val ex = cx + r * cos(th).toFloat()
        val ey = cy + r * sin(th).toFloat()
        val tx = -sin(th).toFloat()   // tangent (clockwise)
        val ty = cos(th).toFloat()
        val nx = cos(th).toFloat()    // radial
        val ny = sin(th).toFloat()
        val p = Path().apply {
            moveTo(ex + tx * 0.5f * u, ey + ty * 0.5f * u)
            lineTo(ex + nx * 0.4f * u, ey + ny * 0.4f * u)
            lineTo(ex - nx * 0.4f * u, ey - ny * 0.4f * u)
            close()
        }
        c.drawPath(p, fill)
    }
}
